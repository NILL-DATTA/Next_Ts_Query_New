export const PRODUCTS = "PRODUCTS";
export const USERS = "USERS";
export const REG = "REG";
export const DETAILS = "DETAILS";
